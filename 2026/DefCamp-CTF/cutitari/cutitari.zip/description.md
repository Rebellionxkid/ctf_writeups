# cutitari

## Difficulty
Hard

## Description
The cuțitari of Craiova disagree about the perfect blade: one inspector wants it blunt; another wants it sharp. The guild's master certificate demands both marks on the same finished knife revision. You get one knife and one trip through the forge.

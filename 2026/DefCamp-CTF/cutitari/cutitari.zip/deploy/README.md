# cutitari

A Craiova knife-makers' workshop: Node.js API, a static UI in `src/ui/` served by stock Caddy under `/ui/`. No browser bot, external packages, or database.

## Run

From this directory, with Docker running:

```sh
FLAG="$(cat ../flag.txt)" docker compose up --build -d
```

Browse <http://localhost:8081> to obtain an account cookie. Port 3000 on the app container must remain private. The externally mapped port is 8081 to avoid clashing with `constangeles`.

Run `python3 ../writeup/solve.py` to verify the two-inspector streamed-response race and its failing sequential control. The script creates fresh workshop accounts through Caddy; it does not use the private app port. The UI script uses a versioned URL and Caddy serves `/ui/` with `Cache-Control: no-store`, so a browser reload cannot retain the old stake/job client. Run `docker compose down` when done.

For organizers, `../../public/handout.zip` contains the player source, deployment files, and description. Exclude `../flag.txt` and `../writeup/` from player files. Set a distinct `FLAG` environment variable in production.

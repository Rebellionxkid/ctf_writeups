const panel = document.createElement('section');
panel.innerHTML = `
<dl>
  <dt>Knife</dt><dd id="knife">…</dd>
  <dt>Edge</dt><dd id="edge">…</dd>
  <dt>Guild marks</dt><dd id="marks">…</dd>
</dl>
<form>
  <button value="reserve">Reserve knife</button>
  <button value="inspect/safety">Safety inspection</button>
  <button value="sharpen">Sharpen</button>
  <button value="inspect/arena">Arena inspection</button>
  <button value="temper">Temper</button>
  <button value="certificate">Request certificate</button>
</form>
<output aria-live="polite"></output>`;
document.body.append(panel);

const $ = (selector) => panel.querySelector(selector);
const out = $('output');
let proof;

async function call(path, method = 'GET') {
  const headers = path === '/inspect/arena' && proof ? { 'X-Safety-Proof': proof } : {};
  const res = await fetch(path, { method, headers });
  if (!res.headers.get('Content-Type')?.startsWith('text/event-stream')) {
    return { ok: res.ok, data: await res.json() };
  }
  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';
  let result = {};
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    let end;
    while ((end = buffer.indexOf('\n\n')) !== -1) {
      const packet = buffer.slice(0, end);
      buffer = buffer.slice(end + 2);
      const kind = /^event: (.+)$/m.exec(packet)?.[1];
      const data = JSON.parse(/^data: (.+)$/m.exec(packet)[1]);
      if (kind === 'proof') {
        proof = data.proof;
        show(true, 'Safety proof ready');
      }
      if (kind === 'stamped' || kind === 'error') result = data;
    }
  }
  return { ok: res.ok && !result.error, data: result };
}

async function refresh() {
  const { ok, data } = await call('/state');
  if (!ok) return show(false, data.error);
  const blade = data.blade;
  $('#knife').textContent = blade?.serial ?? 'None reserved';
  $('#edge').textContent = blade ? `${blade.edge} · revision ${blade.revision}` : '—';
  $('#marks').textContent = blade
    ? ['safety', 'arena'].map(name => `${name}: ${blade.marks[name]?.revision ?? '—'}`).join(' · ')
    : '—';
  $('#marks').className = blade?.marks.safety && blade?.marks.arena ? 'stamped' : '';
}

function show(ok, text) {
  out.className = ok ? '' : 'error';
  out.textContent = text;
}

document.querySelector('form').addEventListener('submit', async (event) => {
  event.preventDefault();
  const action = event.submitter.value;
  const { ok, data } = await call(`/${action}`, action === 'certificate' ? 'GET' : 'POST');
  show(ok, data.error ?? data.flag ?? `${action} completed`);
  refresh();
});

refresh();

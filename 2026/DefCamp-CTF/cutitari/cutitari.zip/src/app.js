const http = require('node:http');
const { randomBytes, pbkdf2 } = require('node:crypto');

const flag = process.env.FLAG || 'DCTF{local_example_not_the_flag}';
const secret = randomBytes(32);
const sessions = new Map();
const fresh = () => randomBytes(16).toString('hex');

function reply(res, status, data) {
  res.writeHead(status, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(data));
}

function engrave(serial, mark, rounds = 3000000) {
  return new Promise((resolve, reject) => {
    pbkdf2(`${serial}:${mark}`, secret, rounds, 32, 'sha256', (err, seal) =>
      err ? reject(err) : resolve(seal.toString('hex')));
  });
}

http.createServer(async (req, res) => {
  const path = new URL(req.url, 'http://workshop').pathname;
  const sid = /(?:^|;\s*)sid=([a-f0-9]{32})(?:;|$)/.exec(req.headers.cookie || '')?.[1];
  let account = sessions.get(sid);

  if (req.method === 'GET' && path === '/') {
    if (!account) {
      const id = fresh();
      account = { blade: null };
      sessions.set(id, account);
      res.setHeader('Set-Cookie', `sid=${id}; HttpOnly; SameSite=Lax; Path=/`);
    }
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
    return res.end(`<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Cuțitari din Craiova</title>
<link rel="stylesheet" href="/ui/ui.css"><script src="/ui/ui.js?v=4" defer></script>
<h1>Cuțitari din Craiova</h1>
<p>Two guild marks, one knife. Earn the cutitari's master certificate.</p>`);
  }

  if (!account) return reply(res, 401, { error: 'Visit / to open a workshop account' });
  const blade = account.blade;

  if (req.method === 'GET' && path === '/state') {
    return reply(res, 200, { blade: blade && {
      serial: blade.serial, edge: blade.edge, revision: blade.revision, marks: blade.marks
    } });
  }
  if (req.method === 'POST' && path === '/reserve') {
    if (blade) return reply(res, 409, { error: 'One knife per workshop account' });
    account.blade = { serial: fresh(), edge: 'blunt', revision: 0, marks: {}, inspecting: {} };
    return reply(res, 200, { serial: account.blade.serial });
  }
  if (req.method === 'POST' && path === '/sharpen') {
    if (!blade || blade.revision !== 0) return reply(res, 409, { error: 'Cannot sharpen this knife' });
    blade.edge = 'sharp';
    blade.revision = 1;
    return reply(res, 200, { edge: blade.edge, revision: blade.revision });
  }
  if (req.method === 'POST' && path === '/temper') {
    if (!blade || blade.revision !== 1) return reply(res, 409, { error: 'Cannot temper this knife' });
    blade.edge = 'blunt';
    blade.revision = 2;
    return reply(res, 200, { edge: blade.edge, revision: blade.revision });
  }
  if (req.method === 'POST' && (path === '/inspect/safety' || path === '/inspect/arena')) {
    const mark = path.slice('/inspect/'.length);
    const eligible = mark === 'safety'
      ? blade?.revision === 0 && blade.edge === 'blunt'
      : blade?.revision === 1 && blade.edge === 'sharp' &&
        blade.proof && req.headers['x-safety-proof'] === blade.proof;
    if (!eligible || blade.marks[mark] || blade.inspecting[mark]) {
      return reply(res, 409, { error: 'This inspection cannot start' });
    }
    blade.inspecting[mark] = true;
    res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-store' });
    res.write('event: admitted\ndata: {}\n\n');
    try {
      let seal = await engrave(blade.serial, mark);
      if (mark === 'safety') {
        blade.proof = seal;
        res.write(`event: proof\ndata: ${JSON.stringify({ proof: seal })}\n\n`);
        seal = await engrave(blade.serial, 'safety:finish', 6000000);
      }
      blade.marks[mark] = { revision: blade.revision, seal };
      res.write(`event: stamped\ndata: ${JSON.stringify({ mark, revision: blade.revision, seal })}\n\n`);
    } catch {
      res.write('event: error\ndata: {"error":"Press unavailable"}\n\n');
    } finally {
      blade.inspecting[mark] = false;
      res.end();
    }
    return;
  }
  if (req.method === 'GET' && path === '/certificate') {
    if (blade?.revision === 2 && blade.edge === 'blunt' &&
        blade.marks.safety?.revision === 2 && blade.marks.arena?.revision === 2) {
      return reply(res, 200, { flag });
    }
    return reply(res, 403, { error: 'The guild marks do not match the finished knife' });
  }
  reply(res, 404, { error: 'Not found' });
}).listen(3000, '0.0.0.0');
